import hashlib
import json
import re
import subprocess
import tomllib
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
plugin = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
reviews = root / 'dev/local/reviews'
tmp = root / 'dev/local/tmp'
ap = root / 'dev/local/autopilot'
state = json.loads((ap / 'state.json').read_text())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
verification = json.loads((ap / 'last-verification.json').read_text())
assert verification['sha'] == head == 'be5e385bd9714952b4803ee30f7c72e661c278f2'
assert all(item['exit'] == 0 for item in verification['commands'])
assert (verification['passed'], verification['failed'], verification['skipped']) == (1352, 0, 0)
alice = (reviews / '00004-cycle-13-alice-output.txt').read_text()
blake = (reviews / '00004-cycle-13-blake-output.txt').read_text()
for text, prefix, ids in ((alice, 'R', [1,2,3,4,6,7,8,9,10,11,12,13]), (blake, 'B', range(1,20))):
    for ident in ids:
        assert re.search(rf'^{prefix}{ident}: (pass|fail)$', text, re.M)
inventory = tomllib.loads((root / 'tests/characterization/current_system.toml').read_text())
items = {item['id']: item for item in inventory['items']}
routes = tomllib.loads((root / 'tests/characterization/migration.toml').read_text())['routes']
owned = [route for route in routes if route['owner_prd'] == '00004']
coverage = [{**items[ident], 'target': route['target']} for route in owned for ident in route['ids']]
assert len(coverage) == len({row['id'] for row in coverage}) == 55
(reviews / '00004-cycle-13-source-coverage.json').write_text(json.dumps(coverage, indent=2) + '\n')
source_table = '\n'.join(f"| {route['target']} | {len(route['ids'])} | {', '.join(route['ids'])} |" for route in owned)
consolidation = subprocess.run([
    'python3', str(plugin / 'skills/review-work-completion/scripts/consolidate_findings.py'),
    f'ALICE:{reviews / "00004-cycle-13-alice-output.txt"}',
    f'BLAKE:{reviews / "00004-cycle-13-blake-output.txt"}',
    '--ledger', str(reviews / '00004-workflow-core-v1-ledger.json'), '--ledger-dismiss', 'BLAKE',
], capture_output=True, text=True, check=True).stdout
(reviews / '00004-cycle-13-consolidation-raw.md').write_text(consolidation)
mechanics = (tmp / 'review-mechanics-00004-cycle-13.md').read_text()
(reviews / '00004-cycle-13-mechanics.md').write_text(mechanics)
previous_checks = json.loads((reviews / '00004-workflow-core-v1-checks-12.json').read_text())
assert all(type(item['result']['exit']) is int and item['result']['exit'] == 0 for item in previous_checks)
(reviews / '00004-workflow-core-v1-checks-13.json').write_text('[]\n')
failure = json.loads((reviews / '00004-cycle-13-dispatch-failure.json').read_text())
report = '''---
prd: dev/local/prds/wip/00004-workflow-core-v1.md
review: 13
date: 2026-09-07
head_sha: be5e385bd9714952b4803ee30f7c72e661c278f2
reviewers: alice,blake
consensus_engine: legacy
status: incomplete
agents:
  alice: available
  blake: available
  bob: unavailable
  carl: unavailable
  eve: unavailable
---

# Cycle 13 — incomplete; paused for unavailable Claude Bob

Diff range: `b43bf2c94d5eb0fddafca55542ef2570b45e8d52..be5e385bd9714952b4803ee30f7c72e661c278f2`

codex_rung_guard: fired (2 codex-implemented task(s)); constraint UNMET

**This is not a completed review.** Bob's external Claude Opus process returned
an API 429 quota rejection before inference. The host contract requires the
independent Claude doubt/de-slop voice every cycle and explicitly requires a
pause if it is unavailable. There is no Bob reviewer text, successful receipt,
or current D1-D5 verdict to certify. No stale cycle-12 rubric is reused.

Quota reset: **2026-09-07 19:50 Europe/Prague (17:50 UTC)**. The dispatch taxonomy
forbids retrying an unchanged exhausted quota. Carl separately exited 3 on the
existing nesting guard; no backend ran, and no permanent batch latch applies.
Fable is unavailable through the native host tools; no Eve dispatch or substitute
Fable model is claimed. The intended external Claude Bob host substitution
could not provide the independent voice. No Codex CLI or guard bypass was used.

[Immutable Bob raw JSONL](00004-cycle-13-bob-output-8e22f932bdb843f896b7c570679c4ab6.jsonl)
and its empty stderr sidecar are retained. [Failure metadata](00004-cycle-13-dispatch-failure.json)
records the raw hash, API error and reset. `autocodex_bob_receipt` is deliberately
absent: the helper creates a receipt only for a successful complete reviewer.

State remains at cycle 13, cap 2, with the same batch, base and 13 completed
tasks. No rework, task retry, cap increase, convergence or finalize transition
was performed. The two candidate repairs below remain findings until the full
review and decision gate can complete. This artifact avoids the canonical
`-review-13.md` filename so an incomplete cycle cannot be skipped on recovery.

## Consolidated findings

The script consolidated only the two successful native reviewers; 1/2 is not
three-provider consensus. Mechanical findings are absorbed below.

'''
report += consolidation
report += '''
| [1/2] | 🟡 | `test_init_rejects_project_config_path_collisions_before_state_publication` hedges with `or`: either outcome satisfies it | tests/state/test_cli.py:372 | general | mech-check; settled R8-K1 |

Terminal observation accounting: **3 findings = 2 open Medium + 1 settled
Medium**. Bob unavailability is a separate review blocker. The settled test
shape is retained, not silently dropped. There are no previous failed or unrun
verification checks to carry forward: all five cycle-12 queue entries record
integer exit 0 at the reviewed HEAD. Bob produced no VERIFY bucket, so this
cycle's queue is empty.

The permission finding is supported by a source-tree probe, not an installed
CLI probe. It fails loudly and does not establish lost data. A safe eventual
repair must retain actual-exit retry/replay durability, peer directory ownership,
identity checks and serialization; blindly stopping confirmation at runtime_root
would reintroduce the earlier crash gap. No architecture choice is made here.

The root self-step is confirmed at `_files.py:255`: `/` is its own parent in
the first iteration and is then confirmed again for the first real component.
The older claim that every ancestor is fsynced twice is inaccurate; only the
root receives this redundant parent sync. It is a concrete small cleanup, not
evidence of missing durability.

Blake's initial High claim that `--ceiling` is unauthorized was withdrawn after
consulting `current_system.toml` TEST-012, which explicitly characterizes override
semantics. CMD-012/DEC-071/TEST-012 are owned by PRD 00004. `policy.py` and the
source CLI retain that behavior. The positive-only domain is not a specified
contract. The original claim is ledger-discarded with this verified reason.

## Coverage and method

All ten source tasks and the three phase exits were reviewed. Alice leaves
P02-T06/P02-T09 and the configured-path acceptance open. The source-owned rows
are mechanically enumerated in [source coverage](00004-cycle-13-source-coverage.json).
The accepted plan digest is `43c75d3d94189351a0c0203c06563eced320889ae2d4cb7ae4e0300873e845a5`.

| Source target | Count | IDs |
|---|---:|---|
'''
report += source_table
report += '''

The computed counts total 55. Alice's raw records subtotal says 31, but its
listed IDs and the manifest compute **28**; the raw response is retained below
and the corrected count is used here. TEST-005 owns parser/document coverage.

Alice and Blake each ran as native `gpt-5.6-sol`, logical tier `sonnet`, with
`fork_turns=none` and independently assembled complete personas/rubrics. Blake
received only the PRD, its mandatory specification links and blind rubric, with
no implementation context, diff, history, handoff, pack or sibling findings.
The native lanes use the same model; no native model-diversity claim is made.
Alice's first coverage summary was identification-only and was returned for
completion; her final report below supersedes it. Her first R2/R12/R13 passes
were corrected to failures: settled disposition does not change binary rubric
truth. Blake's initial rubric failures attached to the withdrawn override claim;
the corrected complete rubric is retained below. Their initial verdict records
remain in the review audit satellite.

All reviewers/processes were awaited. Bob exit 1 and Carl exit 3 were consumed.
The watcher was stopped after Bob's terminal failure and its command session
39333 completed. Alice's probe directory was removed after restoring permissions.

The full review covers 77 changed files. [Mechanical evidence](00004-cycle-13-mechanics.md)
contains per-function facts and test checks. Full-base replay was skipped because
the sandbox denied worktree creation, not because tests passed. Engram pack failed
because the repository is unregistered; no registration or optional pack repair
was attempted. No source tests read live personal runtime state.

The matching `last-verification.json` provides all six successful required gates
at this exact HEAD: uv sync, 1352 pytest tests, Ruff, formatting, mypy and wheel/
sdist build. These results are reused as instructed, not presented as new runs.
Blake additionally reports 431 selected tests, Ruff and mypy passing in his lane;
those do not replace the recorded full-suite counts.

## Alice

'''
report += alice
report += '\n## Blake\n\n' + blake
report += '''
## Bob

Unavailable before inference: API 429, five-hour quota exhausted, resets at
19:50 Europe/Prague. Static doubt/de-slop review did not run. No R or D raw
verdict exists for this cycle and none is fabricated. Intended provider Claude,
requested alias opus; raw model usage is empty, so no actual model is inferred.

## Carl

Unavailable: runner exit 3, `refusing nested dispatch (already inside a CLI agent)`.
No model was dispatched or output consolidated.

Verdict: 3 findings
Tests: 1352 passed, 0 failed, 0 skipped (reused from last-verification.json at be5e385bd9714952b4803ee30f7c72e661c278f2)
'''
report_path = reviews / '00004-workflow-core-v1-cycle-13-incomplete.md'
report_path.write_text(report)
ledger_path = reviews / '00004-workflow-core-v1-ledger.json'
ledger = json.loads(ledger_path.read_text())
withdrawn = {
    'cycle': 13, 'disposition': 'discarded', 'severity': 'high',
    'issue': '`check-plan` exposes an unspecified `--ceiling` override, letting callers bypass the fixed 15-task plan-size policy with a large value and accepting nonsensical negative ceilings instead of rejecting invalid input',
    'file': 'src/ovcaq/workflow_cli.py',
    'reason': 'Withdrawn by Blake: frozen source inventory TEST-012 explicitly requires override semantics, and CMD-012/DEC-071/TEST-012 migrate under PRD 00004. No positive-only domain or fixed non-overridable policy is specified.',
}
if withdrawn not in ledger:
    ledger.append(withdrawn)
ledger_path.write_text(json.dumps(ledger, indent=2, ensure_ascii=False) + '\n')
cycle = {
    'cycle': 13, 'review_file': str(report_path.relative_to(root)),
    'agents': {'alice':'available','blake':'available','bob':'unavailable','carl':'unavailable'},
    'issues_found': 3, 'follow_up_tasks': 0, 'deferred': 1,
    'recurring_issues': ['cycle-12 Pat restricted-ancestor permission concern'],
    'outcome': 'paused_reviewer_unavailable', 'head_sha': head,
    'provider_provenance': {
        'alice': {'provider':'openai','model':'gpt-5.6-sol','logical_tier':'sonnet','agent':'/root/alice_r13','isolated':True},
        'blake': {'provider':'openai','model':'gpt-5.6-sol','logical_tier':'sonnet','agent':'/root/blake_r13','isolated':True},
        'bob': {**failure, 'host_substitution':'external Claude Bob replaces former external Codex doubt role; unavailable before inference'},
        'carl': failure['carl'],
    },
}
(tmp / 'review-13-cycle-record.json').write_text(json.dumps(cycle, indent=2) + '\n')
(tmp / 'review-13-discard-record.json').write_text(json.dumps(withdrawn, indent=2) + '\n')
print(report_path)
