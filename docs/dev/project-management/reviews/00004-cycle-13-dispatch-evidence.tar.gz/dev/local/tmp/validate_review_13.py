import json
import subprocess
import sys
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
plugin = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
sys.path.insert(0, str(plugin / 'skills/run-autopilot'))
sys.path.insert(0, '/Users/bob/.config/autocodex')
from cli.schema import validate
from adapter import review_gap

state = json.loads((root / 'dev/local/autopilot/state.json').read_text())
validate(state)
assert state['phase'] == state['next_phase'] == 'paused'
assert state['cycle'] == 13 and state['rework_cap'] == 2
assert state['batch']['id'] == '202609062243'
assert state['work_start_sha'] == 'b43bf2c94d5eb0fddafca55542ef2570b45e8d52'
assert state['tasks_total'] == len(state['tasks']) == 13
assert state['tasks_completed'] == sum(task['status'] == 'completed' for task in state['tasks']) == 13
assert state['doubts_rubric_verdicts'] == []
assert state['pause_reason']['site'] == 'reviewer_fail'
assert state['rework_task_ids'] == [] and 'review' not in state['phases_completed']
review = root / state['review_cycles'][-1]['review_file']
results = []
commands = [
    (['python3', str(plugin / 'skills/review-work-completion/scripts/check_review_file.py'), '--review-file', str(review), '--require-codex-guard'], 0),
    (['python3', str(plugin / 'skills/run-autopilot/cli/__main__.py'), 'gate', '--review-file', str(review), '--require-codex-guard', '--assert-constraint-met'], 2),
]
for command, expected in commands:
    result = subprocess.run(command, capture_output=True, text=True)
    results.append({'command': command,'exit': result.returncode,'expected':expected,'stdout':result.stdout,'stderr':result.stderr})
    assert result.returncode == expected, results[-1]
gap = review_gap(state, plugin / 'skills/run-autopilot', root, 13)
assert gap == 'missing Claude Bob receipt', gap
results.append({'check':'autocodex host review boundary','result':gap,'expected':'missing Claude Bob receipt'})
results.append({'check':'state/schema and task counts','result':'valid paused state, 13/13, cycle/cap/base/batch preserved'})
(root / 'dev/local/reviews/00004-cycle-13-gate-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
