import hashlib
import json
import tarfile
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
tmp = root / 'dev/local/tmp'
names = {
    'prepare_review_13.py', 'review_13_mechanics.py', 'assemble_review_13.py',
    'review_13_failure.py', 'finalize_review_13.py', 'pause_review_13.py',
    'validate_review_13.py', 'cleanup_review_13.py',
    'review-13-cycle-record.json', 'review-13-discard-record.json',
}
files = sorted(path for path in tmp.iterdir() if path.is_file() and (path.name in names or '00004-cycle-13' in path.name))
assert files and all(not path.is_symlink() for path in files)
hashes = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
archive = root / 'dev/local/reviews/00004-cycle-13-dispatch-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as output:
    for path in files:
        output.add(path, arcname=str(path.relative_to(root)), recursive=False)
with tarfile.open(archive, 'r:gz') as saved:
    for member, digest in hashes.items():
        stream = saved.extractfile(member)
        assert stream is not None
        assert hashlib.sha256(stream.read()).hexdigest() == digest
for path in files:
    path.unlink()
record = {'archive':str(archive),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archived_and_removed':hashes,'probe_cleanup':'Alice removed /private/tmp/tmp2uu0d1ev; permissions restored first'}
(root / 'dev/local/reviews/00004-cycle-13-cleanup.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'archived_files':len(files),'archive':str(archive),'remaining_owned_scratch':[str(path) for path in files if path.exists()]}))
