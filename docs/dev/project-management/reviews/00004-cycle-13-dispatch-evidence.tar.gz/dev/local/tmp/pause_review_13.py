import json
import subprocess
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
state = root / 'dev/local/autopilot/state.json'
cli = '/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1/skills/run-autopilot/scripts/statectl.py'
tmp = root / 'dev/local/tmp'
snapshot = json.loads(state.read_text())
assert snapshot['phase'] == 'review' and snapshot['cycle'] == 13
reason = {'site':'reviewer_fail','detail':'Cycle 13 incomplete: external Claude Bob was rejected before inference (API 429, five-hour quota exhausted; reset 2026-09-07 19:50 Europe/Prague). No receipt or D1-D5 verdict; independent doubt voice unavailable. Two Medium ancestry findings retained. See dev/local/reviews/00004-workflow-core-v1-cycle-13-incomplete.md. Interactive recovery required; preserve cycle 13 and cap 2.'}
mutations = [
    ('set', 'pause_reason', reason),
    ('set', 'phase', 'paused'),
    ('set', 'next_phase', 'paused'),
    ('set', 'review_lenses', {'consensus':'done','blind':'done','doubt':'failed','ui':'failed'}),
    ('set', 'doubts_rubric_verdicts', []),
    ('append', 'review_cycles', json.loads((tmp / 'review-13-cycle-record.json').read_text())),
    ('append', 'autonomous_decisions', {'cycle':13,'issue':'External Claude Bob unavailable before inference','severity':'high','consensus':'coordinator','action':'pause','reason':reason['detail']}),
    ('append', 'autonomous_decisions', {**json.loads((tmp / 'review-13-discard-record.json').read_text()),'action':'discarded','consensus':'1/2; withdrawn by reviewer'}),
]
for verb, key, value in mutations:
    command = ['python3', cli, str(state), verb, key, json.dumps(value)]
    result = subprocess.run(command, capture_output=True, text=True)
    print(json.dumps({'verb':verb,'key':key,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}))
    if result.returncode:
        raise SystemExit(result.returncode)
