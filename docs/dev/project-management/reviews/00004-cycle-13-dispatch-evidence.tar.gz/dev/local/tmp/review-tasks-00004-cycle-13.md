# Completed tasks

## P02-T01: Port PRD selection and lifecycle directory resolution

Accepted source task; implementation and evidence are recorded in the FT-04 build, verification, review, and repair handoffs.

## P02-T02: Port frontmatter parsing/defaults and overwrite warnings

Accepted source task; implementation and evidence are recorded in the FT-04 build, verification, review, and repair handoffs.

## P02-T03: Port transition table and compound phase-complete command

Accepted source task; implementation and evidence are recorded in the FT-04 build, verification, review, and repair handoffs.

## P02-T04: Port resume mapping and plan-size policy

Accepted source task; implementation and evidence are recorded in the FT-04 build, verification, review, and repair handoffs.

## P02-T05: Port reset and completed-PRD summary derivation

Accepted source task; implementation and evidence are recorded in the FT-04 build, verification, review, and repair handoffs.

## P02-T06: Port defer ledger with idempotent operation IDs

Accepted source task, including FT-04F11 complete prospective-ledger validation and durable runtime-ancestor creation; evidence is in rework-11.md.

## P02-T07: Port stall/park filesystem saga and every existing failpoint

Accepted source task; implementation and preservation evidence are recorded in the FT-04 review and repair handoffs.

## P02-T08: Port deterministic audit/report/metrics rendering

Accepted source task, including FT-04F11 serialized report read/compose/publish; evidence is in rework-11.md.

## P02-T09: Replace hardcoded legacy runtime root with configured runtime paths

Accepted source task, including FT-04F11 top-down durable runtime-ancestor creation; evidence is in rework-11.md.

## P02-T10: Generate workflow command documentation from the parser

Accepted source task; implementation and evidence are recorded in the FT-04 build, verification, review, and repair handoffs.

## 1: [C12] Repair runtime ancestor confirmation after abrupt exit (M)

Repair the remaining R11-03 interruption gap, recorded as R12-01.

### Findings (verbatim)
- High: A process exit after creating a runtime ancestor but before fsyncing its parent leaves an existing, unconfirmed directory. A fresh installed defer retry and exact replay return success without fsyncing that parent. | File: src/ovcaq/workflow/_files.py:252 | Task: P02-T06/P02-T09 | Found by: coordinator installed crash probe.
[BOB] 🟡 F2: _ensure_directory_chain dropped exist_ok, so a peer creating the same missing runtime ancestor makes defer fail with a bare FileExistsError; the sibling helper paths.ensure_runtime_directory:102 handles that case | File: src/ovcaq/workflow/_files.py:265 | Task: P02-T06

### Evidence
Review HEAD: 39ecaf4f95c79df6a88c30e4626386a352d1505b. See dev/local/reviews/00004_cycle_12_crash_probe.py and 00004-cycle-12-crash-probe.json. Both injected process exits return 73. Retry/replay return 0 with unchanged authoritative state and one ledger item, but project/new parent fsync is omitted. This is syscall durability evidence and consequent data-loss risk, not observed physical power-loss loss.

### Acceptance
Every quoted finding no longer reproduces. Add a chronological failing installed regression that actually terminates a child before parent fsync, then retries in a fresh process; cover both the first missing ancestor and the configured runtime leaf. Confirm every potentially unconfirmed ancestor entry before successful ledger publication or exact replay. Do not rely on exception cleanup to prove crash recovery. Preserve caught-fsync-error behavior, existing confirmed ancestors, directory identity checks, serialization/sidecar ownership, prospective ledger depth validation, report overlap preservation, complete returned text, state-byte preservation and exactly-once records. All subprocesses must be reaped. Run bounded regression, preservation cases and required full gates. No importer, aliases, provider policy, rollback/abort API, new public knobs, or broad state restructuring. This task is queued only; no implementation is authorized within this review session.

Also preserve safe concurrency when a peer creates the same missing ancestor: verify the resulting directory and confirm its parent, without deleting another writer's directory on a failed sync. Retain a separate installed concurrent-creation regression.

## 2: [D12] Correct publication contention context (S)

### Findings (verbatim)
[BOB] 🟡 F1: Report publication contention reuses the deferred ledger's message and the generic state_io code, so a supervisor can only tell "retry me" from a real disk failure by string-matching the word "retry" | File: src/ovcaq/workflow/_files.py:75 | Task: P02-T08

### Acceptance
Remove the inaccurate deferred-ledger label when report publication is busy; report a precise publication path and contextual retry. The optional proposal to remap contention into revision_conflict is not adopted: this finding establishes misleading context, not a new runtime retry-policy contract. Preserve the current public error taxonomy and state_io exit unless the accepted CLI contract provides a specific existing mapping. This is a bounded diagnostic fix. Keep publication serialization and all behavior intact.

## 3: [D12] Make directory durability assertions meaningful (S)

### Findings (verbatim)
[BOB] 🟡 F3: Assertion cannot fail as written: delegated_calls counts every fsync and directories counts a labeled subset, so the inequality holds by construction | File: tests/packaging/test_rework_11.py:278 | Task: P02-T06
[BOB] ⚪ F5: FSYNC_SCENARIO emits state_changed_while_interrupted; no assertion reads it | File: tests/packaging/rework_11_scripts.py:202 | Task: P02-T06

### Acceptance
Every quoted finding no longer reproduces. Replace/remove the always-true count comparison; bind any retained assertion to required ordered fsync events. Assert the recorded state_changed_while_interrupted value to pin preservation of authoritative state on the failed call, or remove the unused key if another exact assertion already establishes it. Preserve the existing installed fault injection controls and all child cleanup. Do not add framework tests or unrelated coverage.

