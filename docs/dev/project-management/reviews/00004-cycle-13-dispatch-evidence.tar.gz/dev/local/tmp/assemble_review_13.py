import json
import re
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
plugin = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
skill = plugin / 'skills/review-work-completion'
tmp = root / 'dev/local/tmp'
ident = '00004-cycle-13'
out = (skill / 'references/output-formats.md').read_text().split('## Agent Output Format (Single Source of Truth)\n', 1)[1].split('\n## Per-Rule Verdict Format', 1)[0]
rubric = (skill / 'references/rubric.md').read_text()
checklist = (skill / 'references/review-dimensions.md').read_text()
state = json.loads((root / 'dev/local/autopilot/state.json').read_text())
prd = (root / 'dev/local/prds/wip' / state['prd']).read_text()
ledger = json.loads((root / 'dev/local/reviews/00004-workflow-core-v1-ledger.json').read_text())
settled = '\n\n## Settled decisions — do not re-raise\nThese calls were already made in an earlier cycle of this same review, with the reasons given. Do not re-raise them. Raise a NEW finding only if you can show the settled reason no longer holds.\n'
settled += '\n'.join(json.dumps(row, ensure_ascii=False) for row in ledger)
prior = (root / 'dev/local/reviews/00004-workflow-core-v1-review-12.md').read_text().split('## Consolidated findings', 1)[1].split('## Dispatch and method evidence', 1)[0]
handoff = (root / 'dev/local/plans/fast-track-handoffs/00004-workflow-core-v1/rework-12.md').read_text()
for name in ('alice', 'blake', 'bob', 'carl'):
    body = (plugin / f'agents/{name}.md').read_text().split('---', 2)[2].strip()
    mapping = {'{CONTEXT_FILE}': str(tmp / f'review-context-{ident}.md'), '{DIFF_FILE}': str(tmp / f'review-diff-{ident}.diff'), '{PACK_FILE}': '(no pack available this cycle)', '{PACK_FINDINGS}': '(no pack available this cycle)', '{REVIEW_CHECKLIST}': checklist, '{RUBRIC}': rubric, '{OUTPUT_FORMAT}': out, '{PRD}': prd}
    if name == 'blake':
        mapping['{RUBRIC}'] = (plugin / 'skills/review-blindly/references/rubric.md').read_text()
    if name == 'bob':
        eve = (plugin / 'agents/eve.md').read_text()
        body += '\n\n## Two lenses, applied to every changed file' + eve.split('## Two lenses, applied to every changed file', 1)[1]
    for key, value in mapping.items():
        body = body.replace(key, value)
    body += f'\n\nProject root: {root}\nReview only. Do not edit any files, commit, change workflow state, or invoke another reviewer. Return your complete report to the coordinator.\n'
    if name == 'blake':
        body += f'PRD source path (for resolving its specification links): {root / "dev/local/prds/wip" / state["prd"]}\nRead the PRD-linked accepted source plan, coverage manifest, and shared discovery as specification inputs. Do not read implementation plans, history, handoffs, diffs, or sibling findings. The PRD-linked source plan is the requirements authority and is permitted.\n'
    else:
        body += settled
        body += '\n\n## Review scope\nFull PRD range: b43bf2c94d5eb0fddafca55542ef2570b45e8d52..be5e385bd9714952b4803ee30f7c72e661c278f2. The handoff explicitly requires all PRD obligations again. Verify previous findings as well as regressions; do not narrow to repairs. The full source-task and owned-row coverage must be reconciled.\n'
        body += '\n## Prior findings and dispositions\n' + prior
        body += '\n## Work handoff\n' + handoff
        body += '\n## Matching verification record\n' + (root / 'dev/local/autopilot/last-verification.json').read_text()
        body += '\nRecorded verification is evidence, not your own execution. Do not rerun the full suite absent a concrete new concern.\n'
    if name == 'bob':
        body += '\nHost adaptation: You are Bob, a fresh external Claude Opus reviewer substituting for the former external Codex role. Static-only: use Read to inspect files; do not call Bash or execute commands. The full D1-D5 doubt and de-slop intent is mandatory. For each residual finding, emit one canonical [BOB] issue line and place its ID into exactly one FIX/VERIFY/KNOWN bucket. Retain all R and D verdicts. No engram pack is available; do not try to read the sentinel as a path. No design document belongs to your requirements surface.\n'
        # The requirements summary may carry a design doc: give Bob a PRD-only context copy.
        context = (tmp / f'review-context-{ident}.md').read_text()
        summary = (tmp / f'review-prd-{ident}.md').read_text()
        context = context.replace(summary, prd)
        bob_context = tmp / f'bob-context-{ident}.md'
        bob_context.write_text(context)
        body = body.replace(str(tmp / f'review-context-{ident}.md'), str(bob_context))
    (tmp / f'{name}-prompt-{ident}.md').write_text(body + '\n')
    print(f'{name}: {len(body)} chars; prompt {tmp / f"{name}-prompt-{ident}.md"}')
