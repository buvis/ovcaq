import hashlib
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

root = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
reviews = root / 'dev/local/reviews'
raw = reviews / '00004-cycle-13-bob-output-8e22f932bdb843f896b7c570679c4ab6.jsonl'
events = [json.loads(line) for line in raw.read_text().splitlines() if line.strip()]
rate = next(event['rate_limit_info'] for event in events if event.get('type') == 'rate_limit_event')
result = next(event for event in reversed(events) if event.get('type') == 'result')
reset = datetime.fromtimestamp(rate['resetsAt'], ZoneInfo('Europe/Prague')).isoformat()
receipt = reviews / '00004-cycle-13-bob-output.txt.receipt.json'
assert not receipt.exists()
failure = {
    'cycle': 13, 'provider': 'claude', 'requested_model': 'opus',
    'actual_model': None, 'logical_tier': 'opus', 'provider_inference': False,
    'exit': 1, 'api_status': result.get('api_error_status'),
    'reason': result.get('result'), 'reset_at': reset,
    'rate_limit': rate, 'raw': str(raw),
    'raw_sha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
    'stderr': str(raw.with_suffix('.stderr')), 'receipt': None,
    'retry': 'not attempted: confirmed quota rejection; retrying unchanged quota is forbidden by dispatch error taxonomy',
    'carl': {'exit': 3, 'reason': 'refusing nested dispatch (already inside a CLI agent)', 'provider_inference': False},
    'watcher': {'status': 'terminated', 'session_id': 39333, 'result': 'WAITING; command completed and no active wait process remains'},
}
(reviews / '00004-cycle-13-dispatch-failure.json').write_text(json.dumps(failure, indent=2) + '\n')
print(json.dumps({'bob_failure': failure['reason'], 'reset_at': reset, 'receipt': None, 'raw_sha256': failure['raw_sha256']}))
