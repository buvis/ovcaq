import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
PLUGIN = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1')
SKILL = PLUGIN / 'skills/review-work-completion'
TMP = ROOT / 'dev/local/tmp'
ID = '00004-cycle-13'
sys.path.insert(0, str(PLUGIN / 'skills/run-autopilot'))
from cli.schema import validate

state = json.loads((ROOT / 'dev/local/autopilot/state.json').read_text())
validate(state)
assert state['phase'] == state['next_phase'] == 'review'
assert state['cycle'] == 13 and not state.get('pause_reason')
assert state['tasks_total'] == len(state['tasks']) == 13
assert state['tasks_completed'] == sum(t['status'] == 'completed' for t in state['tasks']) == 13
assert not (ROOT / 'dev/local/reviews/00004-workflow-core-v1-review-13.md').exists()
prd_path = ROOT / 'dev/local/prds/wip' / state['prd']
prd = prd_path.read_text()
tasks = '# Completed tasks\n\n'
for task in state['tasks']:
    tasks += f"## {task['id']}: {task['name']}\n\n{task.get('description', '')}\n\n"
(TMP / f'review-tasks-{ID}.md').write_text(tasks)
summary = prd
design = ROOT / state.get('design_doc', f"dev/local/designs/{prd_path.stem}-design.md")
if design.is_file():
    summary += '\n\n## Design Doc\n\n' + design.read_text()
(TMP / f'review-prd-{ID}.md').write_text(summary)
for name in ('alice', 'blake', 'bob', 'eve', 'carl'):
    data = (PLUGIN / f'agents/{name}.md').read_text()
    assert data.startswith('---\n')
    front, body = data.split('---', 2)[1:]
    assert re.search(rf'^name: {name}$', front, re.M)
    assert re.search(r'^description: .+', front, re.M)
    assert re.search(r'^tools: .+', front, re.M)
    assert body.strip()
print(json.dumps({'schema': 'valid', 'tasks': '13/13', 'codex_tasks': sum(any(a.get('implementor') == 'codex' for a in t.get('attempts', [])) for t in state['tasks']), 'blake_filesystem_notes': (ROOT / 'dev/local').is_symlink() or ROOT.name.startswith('.'), 'loop': bool(os.environ.get('_AUTOPILOT_LOOP')), 'unattended': bool(os.environ.get('CLAUDE_UNATTENDED'))}))
