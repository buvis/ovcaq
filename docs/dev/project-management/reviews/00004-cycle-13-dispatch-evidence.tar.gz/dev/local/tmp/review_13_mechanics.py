import hashlib
import json
import subprocess
from pathlib import Path

root = Path('/Users/bob/git/src/github.com/buvis/ovcaq')
skill = Path('/Users/bob/.claude/plugins/cache/buvis-plugins/autopilot/0.5.1/skills/review-work-completion')
tmp = root / 'dev/local/tmp'
state = json.loads((root / 'dev/local/autopilot/state.json').read_text())
base = state['work_start_sha']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only', base, head], text=True).splitlines()
digest = hashlib.sha256((root / 'dev/local/plans/implementation-plan.md').read_bytes()).hexdigest()
assert digest == '43c75d3d94189351a0c0203c06563eced320889ae2d4cb7ae4e0300873e845a5'
blocks = []
for script in ('compute_mech_facts.py', 'detect_tautological_tests.py'):
    result = subprocess.run(['python3', str(skill / 'scripts' / script), *changed], capture_output=True, text=True, check=True)
    blocks.append(result.stdout)
replay = subprocess.run(['python3', str(skill / 'scripts/replay_tests_against_base.py'), '--base', base, '--cmd', str(root / '.venv/bin/python') + ' -m pytest', '--timeout', '90'], capture_output=True, text=True, check=True)
blocks.append(replay.stdout)
(tmp / 'review-mechanics-00004-cycle-13.md').write_text('\n\n'.join(blocks))
context = tmp / 'review-context-00004-cycle-13.md'
text = context.read_text().replace('incremental review (changes since', 'full PRD review (explicit base')
text += '\n\n' + '\n\n'.join(blocks)
text += '\n\n## Architecture\n\n' + (root / 'AGENTS.md').read_text()
text += '\n\n## Mandatory specification inputs\nRead these actual specification sources in full, scoped to PRD 00004: \n'
for path in ('dev/local/plans/implementation-plan.md', 'dev/local/prds/implementation-plan-coverage.md', 'dev/local/discovery/00001-ovcaq-v1.md'):
    text += f'- {root / path}\n'
context.write_text(text)
print(json.dumps({'head': head, 'base': base, 'source_digest': digest, 'changed_files': len(changed), 'mechanics': str(tmp / 'review-mechanics-00004-cycle-13.md')}))
print('\n'.join(line for block in blocks for line in block.splitlines() if '[MECH]' in line or 'replay:' in line))
