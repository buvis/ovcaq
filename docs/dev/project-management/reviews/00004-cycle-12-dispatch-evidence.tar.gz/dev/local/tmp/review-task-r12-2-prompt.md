
You are Pat, the per-task code reviewer. Review the single task's committed
diff below. This review is READ-ONLY: report findings, change nothing.

## Task

Subject: [D12] Correct publication contention context (S)


Description:
### Findings (verbatim)
[BOB] 🟡 F1: Report publication contention reuses the deferred ledger's message and the generic state_io code, so a supervisor can only tell "retry me" from a real disk failure by string-matching the word "retry" | File: src/ovcaq/workflow/_files.py:75 | Task: P02-T08

### Acceptance
Remove the inaccurate deferred-ledger label when report publication is busy; report a precise publication path and contextual retry. The optional proposal to remap contention into revision_conflict is not adopted: this finding establishes misleading context, not a new runtime retry-policy contract. Preserve the current public error taxonomy and state_io exit unless the accepted CLI contract provides a specific existing mapping. This is a bounded diagnostic fix. Keep publication serialization and all behavior intact.


Acceptance criteria:
Report and deferred publication contention use the accurate shared message `publication busy; retry: PATH`, where PATH is the contested output path. Keep the current error type/taxonomy and public state_io exit 2. No retry-policy changes or new public options. Preserve publication serialization and recovery behavior. Only migrate the already-existing diagnostic assertions; do not add new tests for this reversible message change.


## Diff under review

```diff
diff --git a/CHANGELOG.md b/CHANGELOG.md
index 014d7ba..5d12c9e 100644
--- a/CHANGELOG.md
+++ b/CHANGELOG.md
@@ -21,6 +21,7 @@ The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
 
 ### Fixed
 
+- Shared publication contention reports `publication busy; retry: <path>` for both reports and deferred ledgers.
 - Deferred retries and replays confirm existing runtime ancestry after abrupt exits and preserve directories created by concurrent callers when confirmation fails.
 - Deferred publication validates the complete prospective ledger and persists newly created runtime ancestors; overlapping report renders no longer lose successful sections.
 - Report JSON returns the complete published batch text after PRD updates and exact rerenders.
diff --git a/src/ovcaq/workflow/_files.py b/src/ovcaq/workflow/_files.py
index 26aff63..0c01264 100644
--- a/src/ovcaq/workflow/_files.py
+++ b/src/ovcaq/workflow/_files.py
@@ -72,7 +72,7 @@ def _serialize_deferred_publication(path: Path, directory: int) -> Iterator[None
     try:
         fcntl.flock(directory, fcntl.LOCK_EX | fcntl.LOCK_NB)
     except BlockingIOError as error:
-        raise OSError(f"deferred publication busy; retry: {path}") from error
+        raise OSError(f"publication busy; retry: {path}") from error
     try:
         yield
     finally:
diff --git a/tests/packaging/test_rework_11.py b/tests/packaging/test_rework_11.py
index 9402d59..f34c121 100644
--- a/tests/packaging/test_rework_11.py
+++ b/tests/packaging/test_rework_11.py
@@ -308,12 +308,18 @@ def _render_command(installed: InstalledWheel, root: Path) -> list[str | Path]:
     ]
 
 
-def _assert_retry_error(result: subprocess.CompletedProcess[str]) -> None:
+def _assert_retry_error(
+    result: subprocess.CompletedProcess[str], report_path: Path
+) -> None:
     assert result.returncode != 0
     assert result.stdout == ""
     error = json.loads(result.stderr)["error"]
-    assert error["code"]
-    assert "retry" in json.dumps(error).lower()
+    if error["code"] == "state_io":
+        assert result.returncode == 2
+        assert error["message"] == f"publication busy; retry: {report_path}"
+    else:
+        assert error["code"]
+        assert "retry" in json.dumps(error).lower()
     assert "Traceback" not in result.stderr
 
 
@@ -471,14 +477,14 @@ def _retry_failed_overlap_publications(
     b_publication: str | None,
 ) -> tuple[str | None, str | None]:
     if a_result.returncode != 0:
-        _assert_retry_error(a_result)
+        _assert_retry_error(a_result, report_path)
         _set_prd(installed_wheel, root, state_path, "00004-a.md")
         before = state_path.read_bytes()
         retried_a = _run(command, cwd=root, installed_wheel=installed_wheel)
         a_publication = _successful_report_text(retried_a, report_path)
         assert state_path.read_bytes() == before
     if b_result.returncode != 0:
-        _assert_retry_error(b_result)
+        _assert_retry_error(b_result, report_path)
         _set_prd(installed_wheel, root, state_path, "00005-b.md")
         before = state_path.read_bytes()
         retried_b = _run(command, cwd=root, installed_wheel=installed_wheel)
diff --git a/tests/workflow/test_ledger_publication.py b/tests/workflow/test_ledger_publication.py
index e28b503..499a1ae 100644
--- a/tests/workflow/test_ledger_publication.py
+++ b/tests/workflow/test_ledger_publication.py
@@ -70,7 +70,7 @@ def test_sidecar_replacement_inside_native_publish_cannot_lose_successful_append
     rows = load_deferred_records(tmp_path, "batch")
     assert successful <= {row["op_id"] for row in rows}
     assert len(rival_errors) == 1
-    assert "deferred publication busy" in str(rival_errors[0])
+    assert rival_errors[0] == f"publication busy; retry: {path}"
     assert [row["op_id"] for row in rows] == ["seed", "first"]
     for op_id in ("second", "first"):
         record_defer(tmp_path, "00004.md", "batch", {"op_id": op_id})
```

## Recorded verification

The task's tests were run before this review. This is what they reported:

Command: mise exec -- uv run pytest tests/workflow/test_ledger_publication.py::test_sidecar_replacement_inside_native_publish_cannot_lose_successful_append tests/packaging/test_rework_11.py::test_installed_report_overlap_preserves_every_successful_publication -q --basetemp /private/tmp/ovcaq-r12-task-2-green
Exit: 0
Runner summary: 3 passed in 1.00s
HEAD: ee3141b


Judge only from this prompt: the diff above, the task text, and this recorded
result. Do not read other files, run commands, or re-run the tests. What is not
in this prompt is not evidence, and a finding you cannot ground in what is here
is one you should not report.

# Simplification Mandate (step 5.7 reviewer-prompt appendix)

Append this block **verbatim** to every per-task code-reviewer prompt (see
`SKILL.md` step 5.7). It ships inside the prompt, so it must stay
self-contained.

> Beyond bugs, actively hunt for simplification in the diff under review. For
> every added or changed file, ask "what would make this simpler to read
> without changing what it does?" and flag concrete behavior-preserving
> opportunities to: reduce complexity (needless indirection, dead branches,
> single-caller abstractions, nesting deeper than 4 levels, functions over 50
> lines); eliminate redundancy (logic duplicated within the diff or against
> existing code, a helper that reimplements a stdlib or existing utility);
> improve naming (names that state intent, no opaque abbreviations); and
> remove dead code. Follow CLAUDE.md / AGENTS.md conventions and the
> surrounding code's style.
>
> Report each concrete behavior-preserving simplification as a LOW finding,
> with file:line, the current shape, and the simpler replacement. LOW findings
> are carried to the PRD-level review, never retried here.
>
> Do not over-simplify: never propose a change that trades clarity for
> brevity, drops error handling, collapses a deliberate boundary, or removes a
> documented invariant. Simpler means easier to read and maintain, not shorter
> at any cost. If a change would alter behavior, it is out of scope — do not
> flag it.


## Reporting contract

Report one finding per line, in exactly this shape:

SEVERITY | file:line | issue | fix

Severities are CRITICAL, HIGH, MEDIUM, LOW.

Severity has a fixed meaning here, and it decides what happens next. MEDIUM is
reserved for a correctness or security defect this diff introduces that its own
tests do not catch: a wrong result, an unhandled error path, data loss,
injection, secret exposure, or a missing authorization check. Style, naming,
duplication, structure and maintainability are LOW, and so is every
behavior-preserving simplification, whatever its size. A LOW is noted and
carried to the PRD-level review; it is never retried in this loop.

If the diff has no findings, emit the literal line:

NO FINDINGS

## Closure verdicts (only when the description carries a findings block)

When the Description above contains a `### Findings (verbatim)` block, this is
a rework task and each quoted finding is a claim to check. Before your findings
lines, emit one verdict per quoted finding, in this shape:

CLOSURE | resolved|unresolved | <the finding, quoted> | <one line of evidence from the diff>

Judge each finding against the diff, not against the commit message and not
against how clean the code reads. A diff that improves the file while leaving
the quoted defect reachable is `unresolved`. Quote the line that resolves it,
or say what still reaches the defect. Emit a verdict for every quoted finding,
including ones you judge already fixed elsewhere.


