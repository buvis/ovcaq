UNUSED | /Users/bob/git/src/github.com/buvis/ovcaq/tests/packaging/rework_12_scripts.py:132 | ANCESTRY_ACTOR | module-level binding never read in this file

The test module imports ANCESTRY_ACTOR and passes it to installed subprocesses. This is a cross-module exported binding. Do not break that contract: if deletion is unsafe, report the blocker without changes. The original architecture context is unchanged; this hygiene allowlist specifically authorizes the support file below.
